import os
import sys
import random
import re
import time
import json
from pathlib import Path
from collections import defaultdict

from .knowledge import KnowledgeBase
from .user import User
from .sentence_generator import SentenceGenerator
from .word_learner import WordLearner

class FurChat:
    """Основной класс FurChat"""
    
    def __init__(self, base_path="FurChat"):
        self.base_path = Path(base_path)
        self.name = "Рыжий"
        self.kb = KnowledgeBase(base_path)
        self.generator = SentenceGenerator()
        self.word_learner = WordLearner(self.kb)
        self.users = {}
        self.users_path = self.base_path / "memory" / "users"
        self.users_path.mkdir(parents=True, exist_ok=True)
        self._load_users()
        
        # Автоматически учим новые слова при запуске (20% шанс)
        if random.random() < 0.2:
            self.word_learner.learn_new_words(5)
        
        print(f"\n🐺 {self.name} инициализирован")
        print(f"📁 База: {self.base_path}")
        print(f"📚 Слов: {len(self.kb.vocabulary)}")
        print(f"📚 Фраз: {len(self.kb.learned_phrases)}")
    
    def _load_users(self):
        for user_file in self.users_path.glob("*.json"):
            try:
                with open(user_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    user = User.from_dict(data)
                    self.users[user.id] = user
            except:
                pass
    
    def _save_user(self, user):
        user_file = self.users_path / f"{user.id}.json"
        with open(user_file, 'w', encoding='utf-8') as f:
            json.dump(user.to_dict(), f, indent=2, ensure_ascii=False)
    
    def _get_user(self, user_id):
        if user_id not in self.users:
            self.users[user_id] = User(user_id)
        return self.users[user_id]
    
    def _extract_numbers(self, text):
        return re.findall(r'\d+', text)
    
    def get_furry_response(self):
        """Генерирует фурри-ответ с выученными словами"""
        return self.word_learner.get_furry_phrase()
    
    def respond(self, user_id, text, telegram_mode=False):
        if telegram_mode and not self.kb.is_triggered(text):
            return None
        
        user = self._get_user(user_id)
        user.add_message(text)
        
        if self.kb.is_banned(text):
            warnings = [
                "Это нельзя обсуждать.",
                "Не надо так.",
                "Давай без этого.",
                "Закрой тему."
            ]
            return user.get_response_prefix() + random.choice(warnings)
        
        words = re.findall(r'\w+', text.lower())
        if not words:
            return user.get_response_prefix() + "Ну?"
        
        # Проверка специальных фраз
        special = self._check_special(text, user)
        if special:
            return special
        
        qa = self.kb.answer_question(text)
        if qa:
            return user.get_response_prefix() + qa
        
        for word in words:
            if len(word) > 2:
                self.kb.add_word(word)
        
        numbers = self._extract_numbers(text)
        if numbers and random.random() < 0.3:
            num_response = self.generator.generate_with_numbers(numbers)
            if num_response:
                return user.get_response_prefix() + num_response
        
        # 10% шанс использовать фурри-фразу
        if random.random() < 0.1:
            return user.get_response_prefix() + self.get_furry_response()

        if random.random() < 0.3:
            phrase = self.kb.get_random("phrase")
            if phrase:
                return user.get_response_prefix() + phrase
        
        if random.random() < 0.2:
            fact = self.kb.get_random("fact")
            if fact:
                return user.get_response_prefix() + f"Кстати, {fact}"
        
        if len(words) > 2 and random.random() < 0.4:
            key_word = random.choice(words[1:])
        else:
            key_word = words[-1]
        
        context = user.get_context()
        last_response = context[-1] if context else None
        sentence = self.generator.generate(key_word, user.mood, last_response)
        action = self.kb.get_random("action")
        
        if user.mood < -3 and user.relation < 0:
            response = f"{action} Отстань. {sentence}"
        elif user.mood > 3 and user.relation > 0:
            response = f"{action} Классно! {sentence}!"
        elif user.mood < -2:
            response = f"{action} Не беси. {sentence}"
        elif user.mood > 2:
            response = f"{action} Ура! {sentence}"
        else:
            response = f"{action} {sentence}"
        
        if len(text) > 15 and random.random() < 0.15:
            if not text.startswith('/') and '?' not in text:
                new_phrases = self.kb.learned_phrases + [text]
                self.kb.save_learned(new_phrases)
        
        self._save_user(user)
        return user.get_response_prefix() + response
    
    def _check_special(self, text, user):
        text_lower = text.lower()
        
        # Команда для обучения
        if text == '/learn':
            count = self.word_learner.learn_new_words(10)
            return f"📚 Выучил {count} новых слов!"
        
        # Слово дня
        if text == '/word':
            word = self.word_learner.get_word_of_the_day()
            return f"🎯 Слово дня: {word}"
        
        # Приветствия
        greetings = ["привет", "здаров", "здравствуй"]
        if any(g in text_lower for g in greetings):
            return user.get_response_prefix() + self.kb.get_random("greeting")
        
        # Прощания
        goodbyes = ["пока", "до свидания", "увидимся"]
        if any(g in text_lower for g in goodbyes):
            return user.get_response_prefix() + self.kb.get_random("goodbye")
        
        # Имя
        if "как тебя зовут" in text_lower or "твоё имя" in text_lower:
            return f"{self.name}. Просто {self.name}."
        
        # Как дела
        if "как дела" in text_lower:
            return random.choice([
                f"Норм, а у тебя?",
                f"Так себе, сам как?",
                f"Заебись, не жалуюсь!",
                f"Скучно... развлеки меня"
            ])
        
        return None
    
    def console_mode(self, user_id="console_user"):
        print(f"\n🐺 {self.name} - Консольный режим")
        print(f"Команды: /stats, /reload, /memory, /words, /learn, /word, /exit")
        print("="*70)
        print(f"{self.name}: {self.kb.get_random('greeting')}")
        
        while True:
            try:
                text = input("\nТы: ").strip()
                if text == "/exit":
                    print(f"{self.name}: {self.kb.get_random('goodbye')}")
                    break
                elif text == "/stats":
                    user = self._get_user(user_id)
                    print(f"\n📊 Статистика:")
                    print(f"  Настроение: {user.get_mood_string()} ({user.mood})")
                    print(f"  Отношение: {user.get_relation_string()} ({user.relation})")
                    print(f"  Сообщений: {user.message_count}")
                    print(f"  Слов в словаре: {len(self.kb.vocabulary)}")
                    print(f"  Выучено фраз: {len(self.kb.learned_phrases)}")
                elif text == "/reload":
                    self.kb.load_all()
                    print("✅ База обновлена!")
                elif text == "/memory":
                    if self.kb.learned_phrases:
                        print(f"\n📝 Выученное:")
                        for phrase in self.kb.learned_phrases[-10:]:
                            print(f"  • {phrase}")
                    else:
                        print("  Пусто")
                elif text == "/words":
                    print(f"\n📚 Словарь ({len(self.kb.vocabulary)} слов):")
                    words_list = sorted(list(self.kb.vocabulary))[:20]
                    for word in words_list:
                        print(f"  {word}", end=" ")
                    print()
                elif text == "/learn":
                    response = self._check_special(text, self._get_user(user_id))
                    print(f"{self.name}: {response}")
                elif text == "/word":
                    response = self._check_special(text, self._get_user(user_id))
                    print(f"{self.name}: {response}")
                elif text:
                    response = self.respond(user_id, text)
                    print(f"{self.name}: {response}")
            except KeyboardInterrupt:
                print(f"\n{self.name}: Пока!")
                break
            except Exception as e:
                print(f"❌ Ошибка: {e}")
