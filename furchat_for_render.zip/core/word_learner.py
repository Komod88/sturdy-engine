import asyncio
import random
import nest_asyncio
from skyengdict import Dictionary
from collections import defaultdict

nest_asyncio.apply()

class WordLearner:
    """Класс для пополнения словаря бота новыми словами"""
    
    def __init__(self, knowledge_base):
        self.kb = knowledge_base
        if not hasattr(self.kb, 'qa_pairs') or not isinstance(self.kb.qa_pairs, defaultdict):
            self.kb.qa_pairs = defaultdict(list)
        
        self.furry_words = [
            "furry", "fox", "wolf", "dragon", "paws", "tail", "whiskers",
            "fluffy", "fursona", "fursuit", "anthro", "yiff", "scritch",
            "boop", "blep", "murr", "rawr", "nuzzle", "pounce", "paw"
        ]
        self.common_themes = [
            "animal", "emotion", "nature", "food", "weather", "time",
            "family", "friend", "home", "play", "love", "happy"
        ]
        
    async def _fetch_words_async(self, theme, count=5):
        try:
            async with Dictionary() as dictionary:
                results = await dictionary.words(theme, page=1, pagesize=count)
                words = []
                for word_obj in results:
                    if word_obj.language == 'en' and word_obj.text.isalpha():
                        if word_obj.meanings:
                            translation = word_obj.meanings[0].translation
                            words.append({
                                'word': word_obj.text,
                                'translation': translation,
                                'pos': word_obj.meanings[0].part_of_speech_code
                            })
                return words
        except:
            return []
    
    def learn_new_words(self, count=10):
        print(f"\n📚 Учу новые слова...")
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            all_words = []
            themes = random.sample(self.common_themes, min(3, len(self.common_themes)))
            for theme in themes:
                words = loop.run_until_complete(self._fetch_words_async(theme, count=3))
                all_words.extend(words)
            
            added = 0
            for word_info in all_words:
                if word_info['word'] not in self.kb.vocabulary:
                    self.kb.vocabulary.add(word_info['word'])
                    if word_info['translation']:
                        q = f"что значит {word_info['word']}"
                        a = f"{word_info['translation']}"
                        self.kb.qa_pairs[q].append(a)
                    added += 1
            
            self.kb._save_vocabulary()
            print(f"  ✅ Выучено {added} новых слов")
            return added
        finally:
            loop.close()
    
    def get_word_of_the_day(self):
        if self.kb.vocabulary:
            return random.choice(list(self.kb.vocabulary))
        return "furry"
    
    def get_furry_phrase(self):
        templates = [
            "Мой пушистый {word} так и машет",
            "Обожаю чесать за {word}",
            "Сегодня настроение - {word}",
            "Хочу {word} и обнимашки",
            "Мой хвост {word} от счастья"
        ]
        if self.kb.vocabulary:
            word = random.choice(list(self.kb.vocabulary))
            return random.choice(templates).format(word=word)
        return "Я пушистый фурри-лис"
