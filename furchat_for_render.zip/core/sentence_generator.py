import random
import re

class SentenceGenerator:
    """Класс для генерации предложений из слов"""
    
    def __init__(self):
        self.templates = {
            'neutral': [
                "ну {word}",
                "а чё {word}?",
                "{word} как-то так",
                "{word}, если честно",
                "всё дело в {word}",
                "да ну, {word}",
                "типа {word}",
                "короче {word}",
            ],
            'question': [
                "а ты сам {word}?",
                "и что {word}?",
                "зачем тебе {word}?",
                "почему {word}?",
                "когда {word}?",
            ],
            'agreement': [
                "да, {word}",
                "согласен, {word}",
                "точно, {word}",
                "и я так думаю, {word}",
            ],
            'disagreement': [
                "нет, не {word}",
                "вовсе не {word}",
                "а вот и нет, {word}",
            ]
        }
        
        self.starters = ["слушай", "короче", "ну", "типа", "вообще", "знаешь", "представь"]
        self.endings = ["вот так", "такие дела", "ну да", "как-то так", "ага", "ну такое"]
        self.fallback_words = ["ну", "да", "нет", "ок", "ладно", "хм", "понятно"]
    
    def generate(self, word, mood=0, last_response=None):
        if not word or word in ["?", "<UNK>"]:
            word = random.choice(self.fallback_words)
            if random.random() < 0.5:
                return random.choice(self.starters) + " " + word
            return word + ", " + random.choice(self.endings)
        
        if mood < -2:
            template_type = 'disagreement'
        elif mood > 2:
            template_type = 'agreement'
        elif last_response and '?' in last_response:
            template_type = 'question'
        else:
            template_type = random.choice(['neutral', 'question', 'agreement'])
        
        tmpl = random.choice(self.templates.get(template_type, self.templates['neutral']))
        return tmpl.format(word=word)
    
    def generate_with_numbers(self, numbers):
        if not numbers:
            return None
        num = numbers[0]
        templates = [
            f"ну {num}, примерно",
            f"а, {num} понял",
            f"{num}? ок",
            f"запомнил: {num}"
        ]
        return random.choice(templates)
