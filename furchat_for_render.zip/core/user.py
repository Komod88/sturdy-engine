import time
import json
from pathlib import Path
from collections import defaultdict

class User:
    """Класс для хранения данных пользователя"""
    
    def __init__(self, user_id, username=""):
        self.id = user_id
        self.username = username
        self.mood = 0
        self.relation = 0
        self.history = []
        self.topics = defaultdict(int)
        self.first_seen = time.time()
        self.last_seen = time.time()
        self.message_count = 0
    
    def add_message(self, text):
        self.history.append(text)
        if len(self.history) > 50:
            self.history.pop(0)
        
        self.message_count += 1
        self.last_seen = time.time()
        self._update_mood(text)
        self._update_topics(text)
    
    def _update_mood(self, text):
        text_lower = text.lower()
        mood_changes = {
            -2: ["злой", "ненавижу", "бесит"],
            -1: ["грустно", "плохо"],
            1: ["весело", "смешно"],
            2: ["класс", "круто", "отлично"]
        }
        for change, words in mood_changes.items():
            if any(word in text_lower for word in words):
                self.mood += change
        
        relation_changes = {
            1: ["люблю", "ты классный", "хороший"],
            -1: ["плохой", "тупой", "ненавижу тебя"]
        }
        for change, words in relation_changes.items():
            if any(word in text_lower for word in words):
                self.relation += change
        
        self.mood = max(-5, min(5, self.mood))
        self.relation = max(-5, min(5, self.relation))
    
    def _update_topics(self, text):
        for word in text.lower().split():
            if len(word) > 3:
                self.topics[word] += 1
    
    def get_response_prefix(self):
        rel = self.relation
        if rel < -4:
            return "*злобно рычит* "
        elif rel < -2:
            return "*недовольно фыркает* "
        elif rel < 0:
            return "*настороженно косится* "
        elif rel == 0:
            return "*без особых эмоций* "
        elif rel < 3:
            return "*дружелюбно виляет* "
        elif rel < 5:
            return "*радостно* "
        else:
            return "*прыгает от счастья* "
    
    def get_mood_string(self):
        moods = {
            -5: "в ярости", -4: "очень злой", -3: "злой",
            -2: "раздражённый", -1: "недовольный",
            0: "спокойный",
            1: "довольный", 2: "весёлый", 3: "радостный",
            4: "очень радостный", 5: "в восторге"
        }
        return moods.get(self.mood, "неизвестно")
    
    def get_relation_string(self):
        relations = {
            -5: "ненавидит", -4: "презирает", -3: "злится",
            -2: "не доверяет", -1: "насторожен",
            0: "нейтрален",
            1: "симпатизирует", 2: "нравишься", 3: "дружит",
            4: "обожает", 5: "влюблён"
        }
        return relations.get(self.relation, "неизвестно")
    
    def get_context(self, n=3):
        return self.history[-n:] if self.history else []
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'mood': self.mood,
            'relation': self.relation,
            'history': self.history[-20:],
            'topics': dict(self.topics),
            'first_seen': self.first_seen,
            'last_seen': self.last_seen,
            'message_count': self.message_count
        }
    
    @classmethod
    def from_dict(cls, data):
        user = cls(data['id'], data.get('username', ''))
        user.mood = data['mood']
        user.relation = data['relation']
        user.history = data.get('history', [])
        user.topics = defaultdict(int, data.get('topics', {}))
        user.first_seen = data.get('first_seen', time.time())
        user.last_seen = data.get('last_seen', time.time())
        user.message_count = data.get('message_count', 0)
        return user
