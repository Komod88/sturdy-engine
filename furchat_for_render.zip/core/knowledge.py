import os
import json
import random
from pathlib import Path
from collections import defaultdict

class KnowledgeBase:
    """Класс для загрузки и управления знаниями из файлов"""
    
    def __init__(self, base_path):
        self.base_path = Path(base_path)
        self.data_path = self.base_path / "data"
        self.memory_path = self.base_path / "memory"
        self.config_path = self.base_path / "config"
        
        # Создаём папки если нет
        self.data_path.mkdir(parents=True, exist_ok=True)
        self.memory_path.mkdir(parents=True, exist_ok=True)
        self.config_path.mkdir(parents=True, exist_ok=True)
        
        # Данные
        self.greetings = []
        self.goodbyes = []
        self.facts = []
        self.actions = []
        self.qa_pairs = defaultdict(list)
        self.vocabulary = set()
        self.learned_phrases = []
        self.ban_list = []
        self.triggers = []
        
        # Загружаем всё
        self.load_all()
    
    def load_all(self):
        """Загружает все данные из папок"""
        self._load_greetings()
        self._load_goodbyes()
        self._load_facts()
        self._load_actions()
        self._load_qa()
        self._load_vocabulary()
        self._load_learned()
        self._load_ban_list()
        self._load_triggers()
        print(f"  📚 Загружено: {len(self.greetings)} приветствий, {len(self.facts)} фактов, {len(self.vocabulary)} слов")
    
    def _load_list(self, filename, default=None):
        """Загружает список из файла"""
        file_path = self.data_path / filename
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                return [line.strip() for line in f if line.strip()]
        return default if default is not None else []
    
    def _load_greetings(self):
        default = [
            "*лениво вильнул хвостом* Привет...",
            "*вылезает из-под стола* О, живые.",
            "*зевает* И тебе не хворать.",
            "*принюхивается* А, это ты. Привет."
        ]
        self.greetings = self._load_list("greetings.txt", default)
    
    def _load_goodbyes(self):
        default = [
            "Пока.",
            "*отворачивается* Ну, иди.",
            "*зарывается в подушку* Пока, не скучай.",
            "*зевает* Вали уже, я спать хочу."
        ]
        self.goodbyes = self._load_list("goodbyes.txt", default)
    
    def _load_facts(self):
        default = [
            "фурри любят обниматься",
            "у лис пушистый хвост",
            "рыжий лис любит спать",
            "в фурри-сообществе много художников"
        ]
        self.facts = self._load_list("facts.txt", default)

    def _load_actions(self):
        default = [
            "*виляет хвостом*",
            "*чешет за ухом*",
            "*прижимает уши*",
            "*рычит*",
            "*тявкает*",
            "*зевает*",
            "*потягивается*"
        ]
        self.actions = self._load_list("actions.txt", default)
    
    def _load_qa(self):
        file_path = self.data_path / "questions.txt"
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if '|' in line:
                        q, a = line.strip().split('|', 1)
                        self.qa_pairs[q.lower()].append(a)
        
        if not self.qa_pairs:
            self.qa_pairs = {
                "как тебя зовут": ["Рыжий", "меня зовут Рыжий"],
                "ты кто": ["фурри-лис Рыжий", "просто Рыжий"],
                "сколько тебе лет": ["молодой ещё", "не помню уже"],
                "ты бот": ["да, я бот", "программа с душой"]
            }
    
    def _load_vocabulary(self):
        file_path = self.data_path / "words.txt"
        base_words = [
            "привет","пока","как","дела","ты","я","что","где","когда",
            "хорошо","плохо","нормально","отлично","классно",
            "сегодня","завтра","сейчас","потом","всегда",
            "furry","fox","tail","paws","fluffy","happy","sad","love"
        ]
        
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                self.vocabulary = set(line.strip() for line in f if line.strip())
        else:
            self.vocabulary = set(base_words)
            self._save_vocabulary()
    
    def _save_vocabulary(self):
        file_path = self.data_path / "words.txt"
        with open(file_path, 'w', encoding='utf-8') as f:
            for word in sorted(self.vocabulary):
                f.write(word + '\n')
    
    def _load_learned(self):
        file_path = self.memory_path / "learned.txt"
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                self.learned_phrases = [line.strip() for line in f if line.strip()]
    
    def save_learned(self, phrases):
        self.learned_phrases = phrases[-200:]
        file_path = self.memory_path / "learned.txt"
        with open(file_path, 'w', encoding='utf-8') as f:
            for phrase in self.learned_phrases:
                f.write(phrase + '\n')
    
    def _load_ban_list(self):
        file_path = self.config_path / "banlist.txt"
        default = ["суицид","самоубийство","убейся","наркотики","педофил","теракт"]
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                self.ban_list = [line.strip().lower() for line in f if line.strip()]
        else:
            self.ban_list = default
    
    def _load_triggers(self):
        file_path = self.config_path / "triggers.txt"
        default = ["рыжий","рыжик","лис","фурри","бот"]
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                self.triggers = [line.strip().lower() for line in f if line.strip()]
        else:
            self.triggers = default
    
    def add_word(self, word):
        if word and len(word) > 1 and word not in self.vocabulary:
            self.vocabulary.add(word)
            self._save_vocabulary()
            return True
        return False
    
    def get_random(self, category):
        if category == "greeting":
            return random.choice(self.greetings) if self.greetings else "Привет."
        elif category == "goodbye":
            return random.choice(self.goodbyes) if self.goodbyes else "Пока."
        elif category == "fact":
            return random.choice(self.facts) if self.facts else None
        elif category == "action":
            return random.choice(self.actions) if self.actions else "*шевелится*"
        elif category == "phrase":
            return random.choice(self.learned_phrases) if self.learned_phrases else None
        return None
    
    def answer_question(self, text):
        text_lower = text.lower()
        for question, answers in self.qa_pairs.items():
            if question in text_lower:
                return random.choice(answers)
        return None
    
    def is_banned(self, text):
        text_lower = text.lower()
        for word in self.ban_list:
            if word in text_lower:
                return True
        return False
    
    def is_triggered(self, text):
        text_lower = text.lower()
        for trigger in self.triggers:
            if trigger in text_lower:
                return True
        return False
